import junit.framework.TestCase;

public class Test extends TestCase {

	
	public void test() {
		Configuration config = CLIClassique.configuration("-K 10 -A .90 -K 20 -P -K 30 -C".split(" "));
		assertEquals(config.alpha, 0.9);
		assertEquals(config.epsilon, -1.0);
		assertEquals(config.indice, 30);
		assertEquals(config.mode, Mode.CREUSE);
	}

}
