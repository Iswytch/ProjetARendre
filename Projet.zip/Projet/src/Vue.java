
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.*;


public class Vue extends JFrame {
	
	private JFrame fenetre;
	private JButton buttonCreuse  = new JButton("Creuse (C)");
	private JButton buttonPleine  = new JButton("Pleine (P)");
	
	private JButton button1  = new JButton("+");
	private JButton button2  = new JButton("+");
	private JButton button3  = new JButton("+");
	private JTextField field1 = new JTextField();
	private JTextField field2 = new JTextField();
	private JTextField field3 = new JTextField();
	
	private JLabel label;
	
	public Vue() {
	  
	  this.fenetre = new JFrame();
	  this.setLayout(new BorderLayout());

	  
	  JPanel top = new JPanel();
	  top.setLayout(new FlowLayout());
	  top.add(buttonCreuse);
	  top.add(buttonPleine);
	  this.fenetre.add(top,BorderLayout.NORTH);
	  
	  buttonCreuse.addActionListener(e -> addCreuse());
	  buttonPleine.addActionListener(e -> addPleine());
	  
	  
	  JPanel mid = new JPanel();
	  mid.setLayout(new GridLayout(3,3));
	  mid.add(new JLabel("Valeur de l'indice (K)"));
	  mid.add(field1);
	  mid.add(button1);
	  mid.add(new JLabel("Valeur de l'indice (A)"));
	  mid.add(field2);
	  mid.add(button2);
	  mid.add(new JLabel("Valeur de l'indice (E)"));
	  mid.add(field3);
	  mid.add(button3);
	  this.fenetre.add(mid,BorderLayout.CENTER);
	  
	  button1.addActionListener(e -> addIndice(field1));
	  button2.addActionListener(e -> addAlpha(field2));
	  button3.addActionListener(e -> addEpsilon(field3));
	  
	  JPanel bot = new JPanel();
	  label = new JLabel();
	  bot.add(label);
	  
	  this.fenetre.add(bot,BorderLayout.SOUTH);
	  
	  
	  this.fenetre.setSize(500,200);
	  this.fenetre.setVisible(true);
	}

	private void addEpsilon(JTextField field32) {
		label.setText(label.getText()+" -E "+field32.getText());
	}

	private void addAlpha(JTextField field22) {
		label.setText(label.getText()+" -A "+field22.getText());
	}

	private void addIndice(JTextField field12) {
		label.setText(label.getText()+" -K "+field12.getText());
	}

	private void addCreuse() {
		label.setText(label.getText()+" -C");
	}
	
	private void addPleine() {
		label.setText(label.getText()+" -P");
	}

	public static void main(String [] args){
		Vue vu = new Vue();
	}
}