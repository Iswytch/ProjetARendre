public class PageRankClassique {

	public static void main(String... args) {
		System.out.println(args[1]);
		Configuration configuration = CLIClassique.configuration(args);
		System.out.println(configuration);
		// Le reste du programme... Omis.
	}
}
