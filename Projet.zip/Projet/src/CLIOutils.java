import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class CLIOutils {

	
	
	public static CLIClassique fromClass(String nomClass) {
		
		List<String> list = new ArrayList<>();
		try {

			Class c = Class.forName(nomClass);
			System.out.println(c);
	         Field[] fields = c.getDeclaredFields();
	         for(int i = 0; i < fields.length; i++) {
	        	 
	        	 String attName = fields[i].toString().split(nomClass)[1].substring(1);
	        	 String typeAtt = fields[i].toString().split(" ")[1];
	        	 
	        	 if(typeAtt.equals("boolean")) {
	        		 if(Character.isUpperCase(attName.charAt(0))){
	        			 list.add("-" + attName.charAt(0) +" Positionner a faux");
	        		 }else {
	        			 list.add("-" + attName.charAt(0) +" Positionner a vrai");
	        		 }
	        	 }else {
	        		 
	        		 list.add("-" + attName.charAt(0) +" Valeur de "+attName );
	        	 }
	           
	           System.out.println("Attributs is : "+attName);
	          
	         }
	        
	      } catch(Exception e) {
	         System.out.println(e.toString());
	      }
		
		System.out.println(list);
		
		//Il faudrait envoyer les options au CLI, pas assez de temps
		return null;
	}
	
	
	public CLIOutils() {
		fromClass("Configuration");
	}
	
	public static void main(String[] args) {

        new CLIOutils();

    }
}
